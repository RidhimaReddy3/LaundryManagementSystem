from datetime import date, datetime, timedelta
from django.shortcuts import render

from customer.models import OrderDetail, UserDetail
from employee.models import Machines

# Create your views here.


class Home:
    def __init__(self, context={"page": "administrator\main.html"}):
        self.context = context
        self.weekdays = ["Sunday", "Monday", "Tuesday",
                         "Wednesday", "Thursday", "Friday", "Saturday"]

    def homepage(self, request):
        weekly_data = []
        weeks = []
        today_amount = 0
        if request.method == "GET":
            if "cancel_all" in request.GET:
                OrderDetail.objects.filter(
                    Order_date=datetime.today()).delete()
        for days in range(7):
            dday = (datetime.today() - timedelta(days=-(days)))
            order_list = OrderDetail.objects.filter(Order_date=dday)
            total = 0

            for i in order_list:
                if i.Machine in Machines.objects.all():
                    if dday.strftime("%Y-%m-%d") == datetime.today().strftime("%Y-%m-%d"):
                        today_amount += int(i.Order_cost)
                    total += int(i.Order_cost)

            weekly_data.append(total)
            weeks.append(self.weekdays[dday.weekday()])
        if request.method == "POST":
            email1 = request.POST.get('Emp_Email', "abc@gmail.com")
            password1 = request.POST.get('Emp_Password', "abcdef")
            contact = request.POST.get('Emp_Contact', "0")
            role = request.POST.get('Emp_Role', "employee")
            name1 = request.POST.get('Emp_Name', "abc")
            x = UserDetail.objects.create(
                role=role, Email_id=email1, Name=name1, Password=password1, Contact=contact)
            x.save()
        pending_orders = OrderDetail.objects.filter(
            Order_date=datetime.today(), Machine=None).count()

        today_orders = OrderDetail.objects.filter(
            Order_date=datetime.today()).count()
        total_Customers = UserDetail.objects.filter(role="customer").count()
        total_employees = UserDetail.objects.filter(role="employee").count(
        ) + UserDetail.objects.filter(role="manager").count()
        total_orders = 0
        for order in OrderDetail.objects.all():
            if datetime.strptime(str(order.Order_date), "%Y-%m-%d") <= datetime.strptime(datetime.today().strftime("%Y-%m-%d"), "%Y-%m-%d"):
                total_orders += 1
        new = {
            "total_orders": total_orders,
            "total_customers": total_Customers,
            "total_employees": total_employees,
            "today_amount": today_amount,
            "pending_orders": pending_orders,
            "today_orders": OrderDetail.objects.filter(Order_date=datetime.today()).count(),
            "weekly_data": weekly_data[::-1],
            "weeks": weeks[::-1]}
        new.update(self.context)
        return render(request, 'administrator\dashboard.html', new)


class Other(Home):

    def __init__(self, context={"page": "administrator\main.html"}):
        super().__init__(context)

    def customers(self, request):
        user = UserDetail.objects.filter(role="customer").all()
        first_user = UserDetail.objects.filter(role='customer').first()
        new = {"users": user, "first_user": first_user}
        if request.method == "POST" and len(request.POST) == 2:
            if "id" in request.POST:
                id = request.POST["id"]
                user = UserDetail.objects.filter(Id=id).delete()
                print(user)
        if request.method == "GET" and len(request.GET) == 1:
            new["users"] = UserDetail.objects.filter(
                Name__icontains=request.GET['search'], role='customer')
            new["first_user"] = new["users"].first()
        new.update(self.context)
        return render(request, 'administrator\customer.html', new)

    def customer(self, request, item):
        user = UserDetail.objects.filter(role="customer").all()
        first_user = UserDetail.objects.filter(
            role='customer', Id=item).first()
        new = {"users": user, "first_user": first_user}
        if request.method == "GET" and len(request.GET) == 1:
            new["users"] = UserDetail.objects.filter(
                Name__icontains=request.GET['search'], role='customer')
            new["first_user"] = new["users"].first()
        new.update(self.context)
        return render(request, 'administrator\customer.html', new)

    def employees(self, request):
        user = list(UserDetail.objects.filter(role="employee").all()) + \
            list(UserDetail.objects.filter(role="manager").all())
        first_user = UserDetail.objects.filter(role='employee').first()
        new = {"users": user, "first_user": first_user}
        if request.method == "POST" and len(request.POST) == 2:
            if "role" in request.POST:
                role = request.POST["role"].split()[0]
                id = request.POST["role"].split()[1]
                user = UserDetail.objects.filter(Id=id).update(role=role)
                print(user)
            elif "id" in request.POST:
                id = request.POST["id"]
                user = UserDetail.objects.filter(Id=id).delete()
                print(user)
        elif request.method == "GET" and len(request.GET) == 0:
            print("Something")
        elif request.method == "GET" and len(request.GET) == 1:
            new["users"] = UserDetail.objects.filter(
                Name__icontains=request.GET['search'])
            new["first_user"] = new["users"].first()
        new["users"] = list(UserDetail.objects.filter(role="employee").all()) + \
            list(UserDetail.objects.filter(role="manager").all())
        new.update(self.context)
        return render(request, 'administrator\employee.html', new)

    def employee(self, request, item):
        user = list(UserDetail.objects.filter(role="employee").all()) + \
            list(UserDetail.objects.filter(role="manager").all())
        first_user = UserDetail.objects.filter(
            Id=item).first()
        new = {"users": user, "first_user": first_user}
        if request.method == "GET" and len(request.GET) == 1:
            new["users"] = UserDetail.objects.filter(
                Name__icontains=request.GET['search'], role='employee')
            new["first_user"] = new["users"].first()
        new.update(self.context)
        return render(request, 'administrator\employee.html', new)
