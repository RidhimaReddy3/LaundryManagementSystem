from re import S
from urllib import response
from django.test import Client, TestCase
from django.urls import reverse

# Create your tests here.


class UrlTest(TestCase):

    def setUp(self):
        self.client = Client()
        self.homepage = "admins:Homepage"
        self.customers_details = "admins:Customers-Details"
        self.customer_details = "admins:Customer-Details"
        self.employees_details = "admins:Employees-Details"
        self.employee_details = "admins:Employee-Details"
        self.post_csrf = {"csrfMiddlewareToken": "alkhfalksdhflka"}

    def test_homepage_POST(self):
        response = self.client.post(reverse(self.homepage), {'Emp_Name': "Ram Charan", "Emp_Role": "employee",
                                    "Emp_Email": "charan24@gmail.com", "Emp_Password": "abcdef", "Emp_Contact": "1112223334"}.update(self.post_csrf))
        self.assertEqual(response.status_code, 200)

    def test_homepage_GET(self):
        response = self.client.get(reverse(self.homepage))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'administrator\dashboard.html')

    def test_customers_GET(self):
        response = self.client.get(reverse(self.customers_details))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'administrator\customer.html')

    def test_customers_SEARCH(self):
        response = self.client.get(
            reverse(self.customers_details), {'search': "a"})
        self.assertEqual(response.status_code, 200)

    def test_customers_DELETE(self):
        response = self.client.post(reverse(self.customers_details), {
                                    "id": "21"}.update(self.post_csrf))
        self.assertEqual(response.status_code, 200)

    def test_customer(self):
        response = self.client.get(reverse(self.customer_details, args={2}))
        self.assertEqual(response.status_code, 200)

    def test_customer_SEARCH(self):
        response = self.client.get(
            reverse(self.customer_details, args={2}), {"search": "r"})
        self.assertEqual(response.status_code, 200)

    def test_employees(self):
        response = self.client.get(reverse(self.employees_details))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'administrator\employee.html')

    def test_employees_SEARCH(self):
        response = self.client.get(
            reverse(self.employees_details), {'search': "a"})
        self.assertEqual(response.status_code, 200)

    def test_employees_CHANGE_ROLE(self):
        response = self.client.post(reverse(self.employees_details), {
                                    'role': "employee"}.update(self.post_csrf))
        self.assertEqual(response.status_code, 200)

    def test_employees_DELETE(self):
        response = self.client.post(reverse(self.employees_details), {
                                    'id': "3"}.update(self.post_csrf))
        self.assertEqual(response.status_code, 200)

    def test_employee(self):
        response = self.client.get(reverse(self.employee_details, args={7}))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'administrator\employee.html')

    def test_employee_SEARCH(self):
        response = self.client.get(
            reverse(self.employee_details, args={7}), {"search": "r"})
        self.assertEqual(response.status_code, 200)
