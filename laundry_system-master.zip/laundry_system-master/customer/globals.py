class GolbalsValues:
    id = ""
