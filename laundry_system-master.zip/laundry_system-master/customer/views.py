from genericpath import exists
import json
from django.core import serializers
from django.core.mail import EmailMessage
from django.http import HttpResponse
from django.shortcuts import redirect, render
from customer.context_processors import message_processor
from customer.forms import LoginForm, OrderDetailForm
from crispy_forms.layout import *

from employee.models import OrderDresses
from customer.models import Coupon, DressesDetail, FeedBack, OrderDetail, UserDetail
from laundry_system.settings import EMAIL_HOST_USER
from django.template.context_processors import csrf
from .globals import GolbalsValues as gb
# Create your views here.


def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'


class Home:
    context = {"value": True}
    data = {}
    dress_list = []

    def homepage_other(self, request):
        self.context["value"] = True
        dresses = DressesDetail.objects.all()
        self.context.update({})
        new = {'dresses': dresses}
        new.update(self.context)

        if request.method == "POST":  # if form sends POST request then, create customer
            message_processor(request)
            print("Post data:", request.POST)
            # if POST data has 6 fields(i.e name, email, password, contact, csrf_token, submit_button) then create customer with validations, else UserDetail autheticate
            if len(request.POST) == 6:
                form = UserDetail(Name=request.POST['Name'], Email_id=request.POST['Email_id'], Contact=request.POST['Contact'],
                                  Password=request.POST['Password'], role='customer')
                form.save()
                email1 = request.POST["Email_id"]
                #x = UserDetail.objects.filter(Email_id=email1)
                mail = EmailMessage(
                    "Welcome User", "Hello Customer, \nWelcome to our laundry management service", EMAIL_HOST_USER, [email1])
                mail.send()
            elif len(request.POST) == 4:
                form = LoginForm(request.POST)
                # x = auth.authenticate(username=UserDetail.objects.get(username=email1).username,password=password1)
                if form.is_valid():
                    x = UserDetail.objects.get(Email_id=form.cleaned_data.get(
                        "Email_id"), Password=form.cleaned_data.get("Password"))
                    if x is not None:
                        path = x.role
                        gb.id = str(x.Id)
                return redirect("/"+path+"/")
            elif len(request.POST) == 2:
                email1 = request.POST["email1"]
                x = UserDetail.objects.filter(Email_id=email1)
                if len(x) == 1:
                    mail = EmailMessage(
                        "Forgot Password", "Hello Customer, \nYour Password is "+x.first().Password, EMAIL_HOST_USER, [email1])
                    mail.send()
                return redirect("/")
            return redirect("/login")
        else:
            return render(request, "customer\home.html", new)

    def homepage(self, request):
        self.context["value"] = False
        # print(self.context)
        dresses = DressesDetail.objects.all()
        self.context["order_form"] = OrderDetailForm()
        new = {"dresses": dresses}
        if request.method == 'POST':
            # Add dresses in the list
            if "submit" in request.POST:
                dress = DressesDetail.objects.filter(
                    id=request.POST["Dresses_List"]).first()
                total = 0
                if int(request.POST["quantity"]) > 0:
                    if len(self.dress_list) > 0:
                        for i, item in enumerate(self.dress_list):
                            if item['Dress_Name'] == dress.Dress_Name:
                                self.dress_list[i] = {
                                    "Dress_Name": dress.Dress_Name, "quantity": request.POST["quantity"], "cost": dress.Cost*int(request.POST["quantity"])}
                                break
                        else:
                            self.dress_list += [{"Dress_Name": dress.Dress_Name,
                                                 "quantity": request.POST["quantity"], "cost":dress.Cost*int(request.POST["quantity"])}]
                        total = sum([i["cost"] for i in self.dress_list])
                    else:
                        self.dress_list += [{"Dress_Name": dress.Dress_Name,
                                             "quantity": request.POST["quantity"], "cost":dress.Cost*int(request.POST["quantity"])}]
                        total = dress.Cost*int(request.POST["quantity"])
                elif int(request.POST["quantity"]) <= 0:
                    for i, item in enumerate(self.dress_list):
                        if item['Dress_Name'] == dress.Dress_Name:
                            self.dress_list.pop(i)
                new["date"] = request.POST["Order_date"]

                if 'Time_Slot' in request.POST:
                    if request.POST['Time_Slot'] == "0":
                        new["slot"] = "Today"
                    else:
                        new["slot"] = request.POST["Time_Slot"]+":00"
                if 'Coupon' in request.POST and len(request.POST['Coupon']) > 0:
                    coupon = Coupon.objects.filter(
                        Coupon=request.POST['Coupon']).first().Discount
                    if (coupon <= total*0.05):
                        new["hasCoupon"] = True
                        new["Coupon"] = Coupon.objects.get(
                            Coupon=request.POST['Coupon']).Coupon
                        new["coupon_cost"] = coupon
                        total -= coupon
                    elif (coupon <= total*0.10):
                        new["hasCoupon"] = True
                        new["Coupon"] = Coupon.objects.get(
                            Coupon=request.POST['Coupon']).Coupon
                        new["coupon_cost"] = coupon
                        total -= coupon
                    elif (coupon <= total*0.15):
                        new["hasCoupon"] = True
                        new["Coupon"] = Coupon.objects.get(
                            Coupon=request.POST['Coupon']).Coupon
                        new["coupon_cost"] = coupon
                        total -= coupon
                    elif (coupon <= total*0.25):
                        new["hasCoupon"] = True
                        new["Coupon"] = Coupon.objects.get(
                            Coupon=request.POST['Coupon']).Coupon
                        new["coupon_cost"] = coupon
                        total -= coupon
                    elif (coupon <= total*0.5):
                        new["hasCoupon"] = True
                        new["Coupon"] = Coupon.objects.get(
                            Coupon=request.POST['Coupon']).Coupon
                        new["coupon_cost"] = coupon
                        total -= coupon
                new["pickup"] = request.POST["Pickup_date_0"] + \
                    " "+request.POST["Pickup_date_1"]
                new["dress_list"] = self.dress_list
                new["type"] = request.POST["Order_type"]
                new['total'] = total
                new["show"] = len(self.dress_list) > 0
                self.data = dict(new)
            if "Book" in request.POST and len(gb.id) > 0:
                print(self.data)
                data = ["total", "type", "dress_list",
                        "pickup", "Coupon", "date", "slot"]
                length = len(
                    list(filter(lambda each_item: each_item in self.data, data)))
                print(length == len(data))
                if length == len(data) or length == len(data)-1:
                    print("\n\nOrder is created")
                    if length == len(data)-1:
                        self.data["Coupon"] = ""
                    length1 = len(list(filter(lambda each_item: len(
                        str((self.data[each_item]))) > 0, data)))
                    print(length1 == len(data) or length1 == len(data)-1)
                    if length1 == len(data) or length1 == len(data)-1:
                        x = OrderDetail.objects.create(
                            Cust_id=UserDetail.objects.get(Id=gb.id), Order_cost=self.data["total"],
                            Order_type=self.data["type"],
                            Order_date=self.data["date"],
                            Pickup_date=self.data["pickup"],
                            Coupon=self.data["Coupon"],
                            Time_Slot=self.data["slot"])
                        x.save()
                        print("\n\nOrder is Successfull")
                        for i in self.data["dress_list"]:
                            id = DressesDetail.objects.get(
                                Dress_Name=i["Dress_Name"])
                            customer_id = UserDetail.objects.get(Id=gb.id)
                            OrderDresses.objects.create(Order_id=x, Dress_id=id, Quantity=i["quantity"],
                                                        cost=i["cost"]).save()
                            #print("dresses Saved")
                        mail = EmailMessage("Order Created", "Dear Customer, \n\n Your Order (ID: " +
                                            str(x.Id)+") is Created successfully.", EMAIL_HOST_USER, [x.Cust_id.Email_id])
                        mail.send()
                self.dress_list.clear()
        new.update(self.context)
        if request.method == "POST":
            new["order_form"] = OrderDetailForm(request.POST)
        # new = csrf(new)

        return render(request, 'customer\order.html', new)


class Other(Home):

    def profile(self, request):
        self.context["value"] = False
        if len(gb.id) > 0:
            user = UserDetail.objects.get(Id=gb.id)
            new = {"Name": user.Name, "Password_hidden": user.Password,
                   "Email_id": user.Email_id, "Contact": user.Contact}
            if request.method == "POST":
                if 'edit' in request.POST:
                    new["edit"] = True
                elif 'save' in request.POST:
                    new["Name"] = request.POST["name"]
                    new["Email_id"] = request.POST["email"]
                    new["Contact"] = request.POST['contact']
                    new["Password_hidden"] = request.POST["password"]
                    x = UserDetail.objects.filter(Id=gb.id).update(
                        Email_id=new["Email_id"], Name=new["Name"], Password=new["Password_hidden"], Contact=new["Contact"])
                    print("Update:", x)
                    new['edit'] = False
                elif 'delete' in request.POST:
                    x = UserDetail.objects.filter(
                        Id=gb.id).delete()
                    print("Delete:", x)
                    return redirect("/")
                elif 'refer' in request.POST:
                    friends_email = request.POST["referalemail"]
                    mail = EmailMessage(
                        "Referal Link", "Hello customer, \nYou got a referal from your friend to experience our laundry services", EMAIL_HOST_USER,
                        [friends_email])
                    mail.send()
            new.update(self.context)
            return render(request, "customer\profile.html", new)
        else:
            return redirect("/")
            # new = csrf(new)

    def customForm(self, form):
        form.helper.layout = Layout(
            Row(Div(Div(HTML("<b class='col-3' for='Order_date'>{{order_form.Order_date.label}}</b>"), Div(HTML("{{order_form.Order_date}}"), css_class="col-8"), css_class="row text-muted px-2 display-6 fs-4 pb-3"),
                    Div(HTML("<b class='col-3' for='Time_Slot'>{{order_form.Time_Slot.label}}</b>"), Div(HTML(
                        "{{order_form.Time_Slot}}"), css_class="col-8"), css_class="row text-muted px-2 display-6 fs-4 pb-3"),
                    Div(HTML("<b class='col-3' for='Dresses_List'>{{order_form.Dresses_List.label}}</b>"), Div(Row(Div(HTML("{{order_form.Dresses_List}}"), css_class="col-4"), Div(HTML(
                        '<input name="quantity" id="quantity" class="form-control w-75" value="1" type="number">'), css_class="col-3"), Div(Submit('submit', 'Add'), css_class="col-2")), css_class="col-9"), css_class="row text-muted px-2 display-6 fs-4 pb-3"),
                    Div(HTML("<b class='col-3' for='Order_type'>{{order_form.Order_type.label}}</b>"), Div(HTML(
                        "{{order_form.Order_type}}"), css_class="col-8"), css_class="row text-muted px-2 display-6 fs-4 pb-3"),
                    Div(HTML("<b class='col-3' for='Pickup_date'>{{order_form.Pickup_date.label}}</b>"), Div(Row(Div(HTML("{{order_form.Pickup_date.subwidgets.0}}"), css_class="col-5"), Div(
                        HTML("{{order_form.Pickup_date.subwidgets.1}}"), css_class="col-4")), css_class="col-9"), css_class="row text-muted px-2 display-6 fs-4 pb-3"),
                    css_class="col-7"), HTML('''<div class="col-4">
                            <div class="card card-body shadow">
                                <h5 class="card-title text-center m-2">Order</h5>
                                <div class="text-muted fs-6 display-6 py-1"><b>Date: </b><span id="Order_date"></span></div>
                                <div class="text-muted fs-6 display-6 py-1"><b>Order Type: </b><span id="Order_type"></span></div>
                                <div class="text-muted fs-6 display-6 py-1"><b>TimeSlot: </b><span id="Time_Slot"></span></div>
                                <table class="table" id="editTable">
                                    <thead>
                                        <tr>
                                            <th scope="col">Dress_Type</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col">Cost</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    </tbody>
                                </table>
                                <div class="row">
                                    {% if hasCoupon%}
                                    <div class="col-7">
                                        <div class="text-muted fs-6 display-6 pb-3"><b>Coupon: </b>{{Coupon}}</div>
                                    </div>
                                    <div class="col">
                                        <div class="text-muted fs-6 display-6 pb-3 text-center"><b>Discount Cost:</b> {{coupon_cost}}$ </div>
                                    </div>
                                    {% endif %}
                                </div>
                                <div class="row">
                                    <div class="col-7">
                                        <div class="text-muted fs-6 display-6 pb-3"><b>PickUp: </b><span id="Pickup_date"></span></div>
                                    </div>
                                    <div class="col">
                                        <div class="text-muted fs-6 display-6 pb-3 text-center"><b>Total Cost:</b> <span id="Total_cost"></span>$ </div>
                                    </div>
                                </div>

                                <form action="{% url 'CUSTOMER:Homepage'%}" method="POST">
                                    <input type="submit" class="btn btn-success " value="Save" name="Save">
                                </form>
                                </div>
                            </div>''')), Row(Div(HTML('<button type="button" class="btn btn-outline-primary pe-2 editPickup">Edit Pickup</button>'), css_class="col"), Div(HTML('<button type="button" class="btn btn-outline-danger pe-2 cancelOrder">Cancel Order</button>'), css_class="col"))

        )
        return form

    def ordersHistory(self, request):
        dresses = DressesDetail.objects.all()
        if len(gb.id) > 0:
            new = {"dresses": dresses, "mydata": 13}
            new["order_form1"] = OrderDetailForm()
            new["order_form1"].helper.form_id = "edit_form"
            new["order_form1"] = self.customForm(new["order_form1"])
            orders = OrderDetail.objects.filter(Cust_id=gb.id)
            new["hasOrders"] = len(orders) > 0
            if new["hasOrders"]:
                new["orders"] = orders
            if request.method == "GET" and is_ajax(request=request):
                resp = {}
                resp["order"] = serializers.serialize(
                    "json", OrderDetail.objects.filter(Id=request.GET["id"]))
                data = OrderDetail.objects.filter(Id=request.GET["id"]).first()
                resp["dresses"] = serializers.serialize(
                    "json", OrderDresses.objects.filter(
                        Order_id=data))
                resp["dresses_names"] = json.dumps([
                    i.Dress_id.Dress_Name for i in OrderDresses.objects.filter(Order_id=data)])
                print(resp)

                return HttpResponse(json.dumps(resp), content_type="application/json")
            if request.method == "POST":
                if "sendFeedback" in request.POST:
                    toEmail = UserDetail.objects.get(Id=gb.id)
                    mail = EmailMessage("Feedback from Customer", "Customer Email ID: " + toEmail.Email_id +
                                        "\n" + request.POST["feedback"], toEmail.Email_id, [EMAIL_HOST_USER])
                    mail.send()
                    db = FeedBack(Cust_id=toEmail,
                                  Feedback=request.POST["feedback"])
                    db.save()
            new.update(self.context)
            return render(request, "customer/order_history.html", new)
        else:
            return redirect("/")
