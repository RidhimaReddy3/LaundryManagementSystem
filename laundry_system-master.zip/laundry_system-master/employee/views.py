from datetime import datetime
import json
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.core import serializers
from customer.models import DressesDetail, OrderDetail, UserDetail
from customer.globals import GolbalsValues as gb

from employee.models import InventoryDetail, Machines


def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'

# Create your views here.


class Home:

    def __init__(self, context={"page": 'employee\main.html', }):
        self.context = context

    def homepage(self, request):
        new = {}
        new["machines"] = Machines.objects.all()

        if len(gb.id) > 0:
            user = UserDetail.objects.filter(Id=gb.id).first()
            new["order_list"] = OrderDetail.objects.filter(
                Order_date=datetime.today(), Machine=None, Emp_id=None)
            if is_ajax(request) and request.method == "GET":
                resp = {}
                order = OrderDetail.objects.filter(
                    Id=request.GET["Id_value"]).first()
                self.context["id"] = str(order.Id)
                resp["id_ID"] = str(order.Id)
                resp["id_Name"] = str(order.Cust_id.Name)
                resp["id_Email"] = str(order.Cust_id.Email_id)
                resp["id_type"] = str(order.Order_type)
                update = {"machines": []}
                for order_i in OrderDetail.objects.filter(Order_date=order.Order_date, Time_Slot=order.Time_Slot):
                    for machine in new["machines"]:
                        if order_i.Machine == machine:
                            print(order_i.Machine)
                            update["machines"] += [order_i.Machine]
                            break
                for machine in update["machines"]:
                    del new["machines"][new["machines"].indexOf(machine)]

                self.context["machines"] = new["machines"]

                self.context.update(resp)
                return HttpResponse(json.dumps(resp), content_type="application/json")
            elif request.method == "POST":
                print(request.POST)
                if "assign" in request.POST:
                    OrderDetail.objects.filter(Id=self.context['id']).update(
                        Machine=request.POST["machine"], Emp_id=UserDetail.objects.filter(Id=gb.id).first())
            new.update(self.context)
            new["today_total_orders"] = OrderDetail.objects.filter(
                Order_date=datetime.today()).count()
            new["assigned_orders"] = new["today_total_orders"]-OrderDetail.objects.filter(
                Order_date=datetime.today(), Machine=None).count()
            return render(request, 'employee\dashboard.html', new)
        else:
            return redirect("/")


class Other(Home):

    def __init__(self, context={"page": 'employee\main.html'}):
        super().__init__(context)

    def inventory(self, request):
        items = InventoryDetail.objects.all()
        new = {"supply_items": items}
        if is_ajax(request=request) and request.method == "POST":
            resp = {}
            inventory = InventoryDetail.objects.filter(
                Supply_Name=request.POST["supplyName"]).first()
            resp["Supply_NAME"] = inventory.Supply_Name
            resp["Supply_QUANTITY"] = int(
                inventory.Quantity)+int(request.POST["supplyQuantity"])
            self.context.update(resp)
            return HttpResponse(json.dumps(resp), content_type="application/json")
        if "addSubmit" in request.POST:
            if "Supply_NAME" in self.context:
                update = InventoryDetail.objects.filter(Supply_Name=self.context["Supply_NAME"]).update(
                    Quantity=self.context["Supply_QUANTITY"])
                print(update, InventoryDetail.objects.filter(
                    Supply_Name=self.context["Supply_NAME"]))

            new["supply_items"] = InventoryDetail.objects.all()
        new.update(self.context)
        return render(request, "employee\inventory.html", new)

    def inventory1(self, request, item):
        items = InventoryDetail.objects.all()
        item = InventoryDetail.objects.filter(pk=int(item)).first()
        new = {"supply_items": items, "supply_item": item}
        new.update(self.context)
        return render(request, "employee\inventory.html", new)

    def status(self, request):
        self.context = {"page": 'employee\main.html'}
        if is_ajax(request=request) and request.method == "GET":
            machines = serializers.serialize('json', Machines.objects.all())
            orders = []
            if "Id" in request.GET:
                orders = [{"id": str(i.Id), "machine": str(
                    i.Machine)} for i in OrderDetail.objects.filter(Time_Slot=request.GET["Id"]+":00")]
            resp = {"machines": machines, "orders": json.dumps(orders)}
            return HttpResponse(json.dumps(resp), content_type="application/json")
        return render(request, "employee\status.html", self.context)
