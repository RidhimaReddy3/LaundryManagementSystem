import json
from django.http import HttpResponse
from django.shortcuts import render
from customer.models import OrderDetail
from employee.models import Machines
# Create your views here.


def is_ajax(request):
    return request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest'


class Home:

    def __init__(self, context={"page": 'manager/main.html'}):
        self.context = context

    def homepage(self, request):
        machines = Machines.objects.all()
        new = {"machines": machines}
        new["order_list"] = OrderDetail.objects.filter(Time_Slot="Today")

        print(request.POST)
        if request.method == "POST":
            if "Add Machine" in request.POST:
                Machines(Machine_name=request.POST["machine_name"],
                         Type=request.POST["type"], Status=request.POST["status"]).save()
            elif "Edit Machines" in request.POST:
                Machines.objects.filter(id=request.POST["machines"]).update(
                    Status=request.POST["status"])
            elif "Remove Machines" in request.POST:
                Machines.objects.filter(id=request.POST["machines"]).delete()
            elif "approveConfirm" in request.POST:
                print(OrderDetail.objects.filter(Id=self.context['id']))
                OrderDetail.objects.filter(Id=self.context['id']).update(
                    Time_Slot=request.POST["Time_Slot"]+":00")
            elif "declineConfirm" in request.POST:
                OrderDetail.objects.filter(Id=self.context['id']).delete()
        elif request.method == "GET":
            if is_ajax(request) and "approve" in request.GET:
                resp = {}
                order = OrderDetail.objects.filter(
                    Id=request.GET["order_id"]).first()
                self.context["id"] = str(order.Id)
                resp["id_ID"] = str(order.Id)
                resp["id_Name"] = str(order.Cust_id.Name)
                resp["id_Email"] = str(order.Cust_id.Email_id)
                resp["id_type"] = str(order.Order_type)
                self.context.update(resp)
                return HttpResponse(json.dumps(resp), content_type="application/json")
            elif is_ajax(request) and "decline" in request.GET:
                order = OrderDetail.objects.filter(
                    Id=request.GET["order_id"]).delete()
                self.context["id"] = str(order.Id)
        new["order_list"] = OrderDetail.objects.filter(Time_Slot="Today")
        new["total_machines"] = Machines.objects.all().count()
        new["working_machines"] = Machines.objects.filter(
            Status="working").count()
        new.update(self.context)
        return render(request, 'manager\dashboard.html', new)


class Other(Home):

    def __init__(self, context={"page": 'manager/main.html'}):
        super().__init__(context)

    def employeeDashboard(self, request):
        return render(request, 'employee/dashboard.html', self.context)

    def employeeMachineStatus(self, request):
        return render(request, 'employee/status.html', self.context)
